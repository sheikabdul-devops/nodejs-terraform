'use strict';

var Device = require('../model/appModel.js');

exports.list_all_devices = function(req, res) {
  
   Device.getAllDevice(function(err, device) {

    console.log('controller')
    if (err)
      res.send(err);
      console.log('res', device);
      // res.send(device);
      res.render('index' , {device})
  });
};



exports.create_a_device = function(req, res) {
  var new_device = new Device(req.body);

  //handles null error 
   if(!new_device.devicename || !new_device.brand || !new_device.devicetype){

            res.status(400).send({ error:true, message: 'Please provide devicename/brand/devicetype' });

        }
else{
  
  Device.createDevice(new_device, function(err, device) {
    
    if (err)
      res.send(err);
    res.json(device);
  });
}
};


exports.read_a_device = function(req, res) {
  Device.getDeviceById(req.params.deviceId, function(err, device) {
    if (err)
      res.send(err);
      res.json(device);
  });
};


exports.update_a_device = function(req, res) {
  Device.updateById(req.params.deviceId, new Device(req.body), function(err, device) {
    if (err)
      res.send(err);
    res.json(device);
  });
};


exports.delete_a_device = function(req, res) {


  Device.remove( req.params.deviceId, function(err, device) {
    if (err)
      res.send(err);
    res.json({ message: 'Device successfully deleted' });
  });
};


