'user strict';

var mysql = require('mysql');

require('dotenv');

const { RDS_HOSTNAME,RDS_USERNAME,RDS_PASSWORD,RDS_PORT,RDS_DB } = process.env;


var connection = mysql.createConnection({
  host     : RDS_HOSTNAME,
  user     : RDS_USERNAME,
  password : RDS_PASSWORD,
  port     : RDS_PORT,
  database : RDS_DB,
  ssl      : true
});

connection.connect(function(err) {
  if (err) {
	   console.error('Host:' + RDS_HOSTNAME);
	  console.error('Host:' + RDS_USERNAME);
	  console.error('Host:' + RDS_PASSWORD);
	  console.error('Host:' + RDS_PORT);
	  console.error('Host:' + RDS_DB);
    console.error('Database connection failed: ' + err.stack);
    return;
  }

  console.log('Connected to database.');
});

module.exports = connection;
