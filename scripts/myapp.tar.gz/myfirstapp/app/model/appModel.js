'user strict';
var sql = require('./db.js');

//Task object constructor
var Device = function(device){
    this.devicename = device.devicename;
    this.brand = device.brand;
    this.devicetype = device.devicetype;
};
Device.createDevice = function (newDevice, result) {    
        sql.query("INSERT INTO devices set ?", newDevice, function (err, res) {
                
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    console.log(res.insertId);
                    result(null, res.insertId);
                }
            });           
};
Device.getDeviceById = function (deviceId, result) {
        sql.query("Select devicename,brand,devicetype from devices where id = ? ", deviceId, function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    result(null, res);
              
                }
            });   
};
Device.getAllDevice = function (result) {
        sql.query("Select * from devices", function (err, res) {

                if(err) {
                    console.log("error: ", err);
                    result(null, err);
                }
                else{
                  console.log('devices : ', res);  

                 result(null, res);
                }
            });   
};
Device.updateById = function(id, device, result){
  sql.query("UPDATE devices SET devicename = ?, devicetype = ?, brand = ? WHERE id = ?", [device.devicename,device.devicetype,device.brand,id], function (err, res) {
          if(err) {
              console.log("error: ", err);
                result(null, err);
             }
           else{   
             result(null, res);
                }
            }); 
};
Device.remove = function(id, result){
     sql.query("DELETE FROM devices WHERE id = ?", [id], function (err, res) {

                if(err) {
                    console.log("error: ", err);
                    result(null, err);
                }
                else{
               
                 result(null, res);
                }
            }); 
};

module.exports= Device;

