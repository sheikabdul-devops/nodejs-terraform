'use strict';
module.exports = function(app) {
  var deviceList = require('../controller/appController');

  // todoList Routes
  app.route('/devices')
    .get(deviceList.list_all_devices)
    .post(deviceList.create_a_device);
   
   app.route('/devices/:deviceId')
    .get(deviceList.read_a_device)
    .put(deviceList.update_a_device)
    .delete(deviceList.delete_a_device);
    };

